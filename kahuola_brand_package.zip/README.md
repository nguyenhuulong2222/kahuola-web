# Kahu Ola — Full Brand Package (Clean SVG)

This package includes:
- logo-lockup.svg (horizontal lockup: mark + wordmark + tagline)
- logo-mark.svg (mark only)

Exports:
- exports/png/logo-lockup.png
- exports/png/logo-mark.png
- exports/favicons/favicon.ico + favicon-*.png + apple-touch-icon.png
- exports/app_icon/app-icon-1024-light.png + app-icon-1024-dark.png
- exports/social/social-preview-1200x630.png

Note:
- The SVG artwork is vector paths for the mark and ring.
- Wordmark is editable SVG text using system fonts for web consistency.
  If you want the wordmark converted to outline paths, tell me the exact font file/name to use.
